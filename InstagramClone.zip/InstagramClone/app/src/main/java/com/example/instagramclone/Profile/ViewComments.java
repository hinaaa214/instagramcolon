package com.example.instagramclone.Profile;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.instagramclone.R;
import com.example.instagramclone.Utils.CommentListAdapter;
import com.example.instagramclone.models.Comments;
import com.example.instagramclone.models.Photo;
import com.example.instagramclone.models.Users;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


public class ViewComments extends AppCompatActivity {

    private static final String TAG = "ViewComments";
    ImageView civUserImg, ivGoBack;
    //vars
    Photo mphoto;
    ArrayList<Comments> mComments;
    Integer commentCount;
    private EditText etWriteComment;
    private ListView mListView;
    private TextView tvPostComment;
    private FirebaseAuth.AuthStateListener fbAuthStateListener;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_comments);

        //widgets
        ivGoBack = findViewById(R.id.ivGoBack);
        etWriteComment = findViewById(R.id.etWriteComment);
        mListView = findViewById(R.id.listView);
        tvPostComment = findViewById(R.id.tvPostComment);
        civUserImg = findViewById(R.id.civUserImg);
        mComments = new ArrayList<>();

        try {
            mphoto = getPhotoFromBundle();
            commentCount = getIntent().getIntExtra("commentCount", 0);
            Log.d(TAG, "getPhotoFromBundle: arguments: " + mphoto);

            getCommentList();

        } catch (NullPointerException e) {
            Log.e(TAG, "onCreateView: NullPointerException: " + e.getMessage());
        }
        // Retrieving profile photo
        String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userid);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                final Users user = snapshot.getValue(Users.class);
                Glide.with(ViewComments.this)
                        .load(Objects.requireNonNull(user).getProfilePhoto())
                        .into(civUserImg);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private Photo getPhotoFromBundle() {

        Bundle bundle = getIntent().getExtras();
//        Log.d(TAG, "getPhotoFromBundle: arguments: " + bundle.getParcelable("Photo"));
        if (bundle != null)
            return bundle.getParcelable("Photo");
        else
            return null;
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void addNewComment(String newComment) {
        Log.d(TAG, "addNewComment: adding new comment: " + newComment);

        String commentId = dbRef.push().getKey();

        Comments comment = new Comments();
        comment.setComment(newComment);
        comment.setDate_created(getTimestamp());
        comment.setUser_id(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid());

        //insert into photos node
        dbRef.child("Photo")
                .child(mphoto.getPhotoId())
                .child("comments")
                .child(Objects.requireNonNull(commentId))
                .setValue(comment);

        //insert into user_photos node
        dbRef.child("User_Photo")
                .child(mphoto.getUserId())
                .child(mphoto.getPhotoId())
                .child("comments")
                .child(commentId)
                .setValue(comment);

        addCommentNotification(comment.getComment(), mphoto.getUserId(), mphoto.getPhotoId());

    }

    private String getTimestamp() {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }

    private void getCommentList() {
        Log.d(TAG, "getCommentList: Comments");

        //firebase
        FirebaseAuth fbAuth = FirebaseAuth.getInstance();
        FirebaseDatabase fbDatabase = FirebaseDatabase.getInstance();
        dbRef = fbDatabase.getReference();

//        if(mphoto.getComments().size() == 0){
        if (commentCount == 0) {
            mComments.clear();
            Comments firstComment = new Comments();
            firstComment.setUser_id(mphoto.getUserId());
            firstComment.setComment(mphoto.getCaption());
            firstComment.setDate_created(mphoto.getDateCreated());
            mComments.add(firstComment);
            mphoto.setComments(mComments);
            setupWidgets();
        }


        dbRef.child("Photo")
                .child(mphoto.getPhotoId())
                .child("comments")
                .addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                        Log.d(TAG, "onChildAdded: child added.");

                        Query query = dbRef
                                .child("Photo")
                                .orderByChild("photo_id")
                                .equalTo(mphoto.getPhotoId());
                        query.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dsnapshot) {
                                for (DataSnapshot singleSnapshot : dsnapshot.getChildren()) {
                                    Photo photo = new Photo();
                                    Map<String, Object> objectMap = (HashMap<String, Object>) singleSnapshot.getValue();

                                    photo.setCaption(Objects.requireNonNull(objectMap.get("caption")).toString());
                                    photo.setTags(Objects.requireNonNull(objectMap.get("tags")).toString());
                                    photo.setPhotoId(Objects.requireNonNull(objectMap.get("photo_id")).toString());
                                    photo.setUserId(Objects.requireNonNull(objectMap.get("user_id")).toString());
                                    photo.setDateCreated(Objects.requireNonNull(objectMap.get("date_Created")).toString());
                                    photo.setImagePath(Objects.requireNonNull(objectMap.get("image_Path")).toString());

                                    mComments.clear();
                                    Comments firstComment = new Comments();
                                    firstComment.setUser_id(mphoto.getUserId());
                                    firstComment.setComment(mphoto.getCaption());
                                    firstComment.setDate_created(mphoto.getDateCreated());
                                    mComments.add(firstComment);

//                                    List<Comments> commentsList = new ArrayList<Comments>();
                                    for (DataSnapshot dSnapshot : singleSnapshot
                                            .child("comments").getChildren()) {
                                        Comments comments = new Comments();
                                        comments.setUser_id(dSnapshot.getValue(Comments.class).getUser_id());
                                        comments.setComment(dSnapshot.getValue(Comments.class).getComment());
                                        comments.setDate_created(dSnapshot.getValue(Comments.class).getDate_created());
                                        mComments.add(comments);
                                    }
                                    photo.setComments(mComments);
                                    mphoto = photo;
                                    setupWidgets();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });

    }

    private void setupWidgets() {

        CommentListAdapter adapter = new CommentListAdapter(this, R.layout.layout_each_comment, mComments);
        mListView.setAdapter(adapter);

        tvPostComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!etWriteComment.getText().toString().isEmpty()) {
                    Log.d(TAG, "onClick: attempting to submit new comment.");
                    addNewComment(etWriteComment.getText().toString());

                    etWriteComment.setText("");
                    closeKeyboard();
                } else
                    Toast.makeText(ViewComments.this, "you can't post a blank comment", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void addCommentNotification(String comment, String userid, String postid) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Notifications");

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("userId", Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid());
        hashMap.put("text", "Commented!" + comment);
        hashMap.put("postId", postid);
        hashMap.put("isPost", true);
        reference.child(userid).push().setValue(hashMap);
    }
}