package com.example.instagramclone.models;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class Photo implements Parcelable {
    public static final Creator<Photo> CREATOR = new Creator<Photo>() {
        @Override
        public Photo createFromParcel(Parcel in) {
            return new Photo(in);
        }

        @Override
        public Photo[] newArray(int size) {
            return new Photo[size];
        }
    };
    private String caption, dateCreated, imagePath, photoId, userId, tags;
    private List<Likes> likes;
    private List<Comments> comments;


    public Photo(String caption, String dateCreated, String imagePath, String photoId,
                 String userId, String tags, List<Likes> likes, List<Comments> comments) {
        this.caption = caption;
        this.dateCreated = dateCreated;
        this.imagePath = imagePath;
        this.photoId = photoId;
        this.userId = userId;
        this.tags = tags;
        this.likes = likes;
        this.comments = comments;
    }


    public Photo() {
    }

    protected Photo(Parcel in) {
        caption = in.readString();
        dateCreated = in.readString();
        imagePath = in.readString();
        photoId = in.readString();
        userId = in.readString();
        tags = in.readString();
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getPhotoId() {
        return photoId;
    }

    public void setPhotoId(String photoId) {
        this.photoId = photoId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public List<Likes> getLikes() {
        return likes;
    }

    public void setLikes(List<Likes> likes) {
        this.likes = likes;
    }

    public List<Comments> getComments() {
        return comments;
    }

    public void setComments(List<Comments> comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "Photo{" +
                "Caption='" + caption + '\'' +
                ", Date_Created='" + dateCreated + '\'' +
                ", Image_Path='" + imagePath + '\'' +
                ", Photo_id='" + photoId + '\'' +
                ", User_id='" + userId + '\'' +
                ", Tags='" + tags + '\'' +
                ", likes=" + likes +
                ", comments=" + comments +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(caption);
        dest.writeString(dateCreated);
        dest.writeString(imagePath);
        dest.writeString(photoId);
        dest.writeString(userId);
        dest.writeString(tags);
    }
}
