package com.example.instagramclone.Profile;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;
import com.example.instagramclone.R;
import com.example.instagramclone.Utils.GridImageAdapter;
import com.example.instagramclone.models.Comments;
import com.example.instagramclone.models.Likes;
import com.example.instagramclone.models.Photo;
import com.example.instagramclone.models.Users;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ProfileFragment extends Fragment {

    private static final int NUM_GRID_COLUMNS = 3;
    private static final String TAG = "ProfileFragment";

    // hooks for the UI elements
    ImageView ivSettingMenu;
    Button btnEditProfile;
    ImageView civUserImg;
    GridView gridview1;
    TextView tvPosts, tvFollowers, tvFollowing, tvDisplayName, tvDescription, tvUsername;
    LinearLayout llFollowers, llFollowing;

    String noFollowers, noFollowings;
    DatabaseReference databaseReference;
    private ProgressBar profileProgressBar;

    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        @SuppressLint("InflateParams") View v = inflater.inflate(R.layout.fragment_profile, null);

        ivSettingMenu = v.findViewById(R.id.ivSettingMenu);
        btnEditProfile = v.findViewById(R.id.btnEditProfile);
        civUserImg = v.findViewById(R.id.civUserImg);
        gridview1 = v.findViewById(R.id.gridview1);
        tvPosts = v.findViewById(R.id.tvPosts);
        tvFollowers = v.findViewById(R.id.tvFollowers);
        tvFollowing = v.findViewById(R.id.tvFollowing);
        tvDisplayName = v.findViewById(R.id.tvFullName);
        tvDescription = v.findViewById(R.id.tvDescription);
        tvUsername = v.findViewById(R.id.tvUsername);
        llFollowers = v.findViewById(R.id.llFragProfileFollower);
        llFollowing = v.findViewById(R.id.llFragProfileFollowing);
        profileProgressBar = v.findViewById(R.id.profileProgressBar);

        // Retrieving Photos and displaying in profile
        tempGridSetup();

        // Retrieving data
        String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userid);
        databaseReference.keepSynced(true);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                final Users user = snapshot.getValue(Users.class);
                tvPosts.setText(user.getPosts());
                noFollowers = user.getFollowers();
                noFollowings = user.getFollowing();
                tvFollowers.setText(noFollowers);
                tvFollowing.setText(noFollowings);
                tvDisplayName.setText(user.getFullName());
                tvDescription.setText(user.getDescription());
                tvUsername.setText(user.getUserName());
                Glide.with(ProfileFragment.this)
                        .load(user.getProfilePhoto())
                        .into(civUserImg);
                profileProgressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getActivity(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        ivSettingMenu.setOnClickListener(v1 -> {
            Intent intent = new Intent(getActivity(), Account_Settings.class);
            startActivity(intent);
        });
        btnEditProfile.setOnClickListener(v12 -> {
            Intent intent = new Intent(getActivity(), EditProfile.class);
            startActivity(intent);
        });

        llFollowers.setOnClickListener(v13 -> {
            Intent intent = new Intent(getContext(), FollowersFollowing.class);
            intent.putExtra("id", FirebaseAuth.getInstance().getCurrentUser().getUid());
            intent.putExtra("title", "Followers");
            intent.putExtra("number", noFollowers);
            startActivity(intent);

        });

        llFollowing.setOnClickListener(v14 -> {
            Intent intent = new Intent(getContext(), FollowersFollowing.class);
            intent.putExtra("id", FirebaseAuth.getInstance().getCurrentUser().getUid());
            intent.putExtra("title", "Following");
            intent.putExtra("number", noFollowings);
            startActivity(intent);
        });
        return v;
    }

    private void tempGridSetup() {
        Log.d(TAG, "setupGridView: Setting up image grid.");
        final ArrayList<Photo> photos = new ArrayList<>();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.keepSynced(true);
        Query query = reference
                .child("User_Photo")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot singleSnapshot : snapshot.getChildren()) {
                    Photo photo = new Photo();
                    Map<String, Object> objectMap = (HashMap<String, Object>) singleSnapshot.getValue();
                    Log.d(TAG, "setupGridView(objectMap)" + objectMap.get("caption"));


                    photo.setCaption(Objects.requireNonNull(objectMap.get("caption")).toString());
                    photo.setTags(Objects.requireNonNull(objectMap.get("tags")).toString());
                    photo.setPhotoId(Objects.requireNonNull(objectMap.get("photo_id")).toString());
                    photo.setUserId(Objects.requireNonNull(objectMap.get("user_id")).toString());
                    photo.setDateCreated(Objects.requireNonNull(objectMap.get("date_Created")).toString());
                    photo.setImagePath(Objects.requireNonNull(objectMap.get("image_Path")).toString());

                    List<Comments> comments = new ArrayList<Comments>();
                    for (DataSnapshot dSnapshot : singleSnapshot
                            .child("comments").getChildren()) {
                        Comments comment = new Comments();
                        comment.setUser_id(dSnapshot.getValue(Comments.class).getUser_id());
                        comment.setComment(dSnapshot.getValue(Comments.class).getComment());
                        comment.setDate_created(dSnapshot.getValue(Comments.class).getDate_created());
                        comments.add(comment);
                    }

                    photo.setComments(comments);

                    List<Likes> likesList = new ArrayList<Likes>();
                    for (DataSnapshot dSnapshot : singleSnapshot
                            .child("likes").getChildren()) {
                        Likes like = new Likes();
                        like.setUser_id(dSnapshot.getValue(Likes.class).getUser_id());
                        likesList.add(like);
                    }
                    photo.setLikes(likesList);
                    photos.add(photo);
//                    photos.add(singleSnapshot.getValue(Photo.class));
                }

                //setup our image grid
                int gridWidth = getResources().getDisplayMetrics().widthPixels;
                int imageWidth = gridWidth / NUM_GRID_COLUMNS;
                gridview1.setColumnWidth(imageWidth);

                ArrayList<String> imgUrls = new ArrayList<String>();

                for (int i = 0; i < photos.size(); i++)
                    imgUrls.add(photos.get(i).getImagePath());


                GridImageAdapter adapter = new GridImageAdapter(getActivity(), R.layout.layout_grid_imageview,
                        "", imgUrls);
                gridview1.setAdapter(adapter);

                gridview1.setOnItemClickListener((parent, view, position, id) -> {

                    ViewPostFragment fragment = new ViewPostFragment();
                    Bundle args = new Bundle();
                    args.putParcelable("PHOTO", photos.get(position));
                    Log.d(TAG, "getPhotoFromBundle(PHOTO): arguments: " + photos.get(position));

                    fragment.setArguments(args);
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(ProfileFragment.this.getId(), fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.d(TAG, "onCancelled: query cancelled.");
            }
        });
    }

    @Override
    public void onResume() {

        super.onResume();
        this.getView().setFocusableInTouchMode(true);
        this.getView().requestFocus();

        this.getView().setOnKeyListener((v, keyCode, event) -> keyCode == KeyEvent.KEYCODE_BACK);
    }
}
