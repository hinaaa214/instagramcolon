package com.example.instagramclone.Messages;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.instagramclone.Messages.Adapter.MessageAdapter;
import com.example.instagramclone.Messages.Model.Chat;
import com.example.instagramclone.Messages.Notification.APIService;
import com.example.instagramclone.Messages.Notification.Client;
import com.example.instagramclone.Messages.Notification.Data;
import com.example.instagramclone.Messages.Notification.MyResponse;
import com.example.instagramclone.Messages.Notification.NotificationSender;
import com.example.instagramclone.Messages.Notification.Token;
import com.example.instagramclone.R;
import com.example.instagramclone.models.Users;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MessageActivity extends AppCompatActivity {

    CircleImageView profile_image;
    TextView username, fullName;

    FirebaseUser fbUser;
    DatabaseReference reference;
    Intent intent;
    boolean notify = false;
    TextView btn_send;
    EditText text_send;
    MessageAdapter messageAdapter;
    List<Chat> msgChat;
    RecyclerView recyclerView;
    String userid;
    private APIService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        Toolbar toolbar = findViewById(R.id.MessageActivity_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        username = findViewById(R.id.MessageActivity_userName);
        fullName = findViewById(R.id.MessageActivity_fullName);
        profile_image = findViewById(R.id.MessageActivity_user_img);
        btn_send = findViewById(R.id.MessageActivity_btn_send);
        text_send = findViewById(R.id.MessageActivity_text_send);

        apiService = Client.getClient("https://fcm.googleapis.com/").create(APIService.class);

        recyclerView = findViewById(R.id.MessageActivity_recyclerView);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        intent = getIntent();
        userid = intent.getStringExtra("userid");

        fbUser = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Users user = dataSnapshot.getValue(Users.class);
                assert user != null;
                username.setText(user.getUserName());
                fullName.setText(user.getFullName());
                Glide.with(MessageActivity.this)
                        .load(user.getProfilePhoto())
                        .into(profile_image);
                readMessages(fbUser.getUid(), userid, user.getProfilePhoto());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        btn_send.setOnClickListener(view -> {
            notify = true;
            String msg = text_send.getText().toString();
            if (!msg.isEmpty())
                sendMessage(fbUser.getUid(), userid, msg);
            else
                Toast.makeText(MessageActivity.this, "You can't send empty message",
                        Toast.LENGTH_SHORT).show();

            text_send.setText("");
            closeKeyboard();
        });

    }

    private void sendMessage(String sender, final String receiver, String message) {

        DatabaseReference dbReference = FirebaseDatabase.getInstance().getReference();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("sender", sender);
        hashMap.put("receiver", receiver);
        hashMap.put("message", message);
        hashMap.put("isSeen", false);

        dbReference.child("Chats").push().setValue(hashMap);

        final String msg = message;
        dbReference = FirebaseDatabase.getInstance().getReference("Users").child(fbUser.getUid());
        dbReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Users user = dataSnapshot.getValue(Users.class);
                if (notify) {
                    assert user != null;
                    sendNotification(receiver, user.getUserName(), msg);
                }
                notify = false;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void sendNotification(String receiver, final String username, final String message) {

        DatabaseReference tokens = FirebaseDatabase.getInstance().getReference("Tokens");
        Query query = tokens.orderByKey().equalTo(receiver);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Token token = snapshot.getValue(Token.class);
                    Data data = new Data(fbUser.getUid(), R.mipmap.ic_launcher_instaclone,
                            username + ":" + message, "New Message", userid);

                    NotificationSender sender = new NotificationSender(data,
                            Objects.requireNonNull(token).getToken());

                    apiService.sendNotification(sender).enqueue(new Callback<MyResponse>() {
                        @Override
                        public void onResponse(@NonNull Call<MyResponse> call,
                                               @NonNull Response<MyResponse> response) {
                            if (response.code() == 200)
                                if (Objects.requireNonNull(response.body()).success != 1)
                                    Toast.makeText(MessageActivity.this, "Failed",
                                            Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onFailure(@NonNull Call<MyResponse> call, @NonNull Throwable t) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void readMessages(final String myId, final String userid, final String imageUrl) {
        msgChat = new ArrayList<>();

        reference = FirebaseDatabase.getInstance().getReference("Chats");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                msgChat.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Chat chat = snapshot.getValue(Chat.class);
                    if (Objects.requireNonNull(chat).getReceiver().equals(myId) && chat.getSender().
                            equals(userid) || chat.getReceiver().equals(userid) &&
                            chat.getSender().equals(myId)) {
                        msgChat.add(chat);
                    }
                    messageAdapter = new MessageAdapter(MessageActivity.this, msgChat, imageUrl);
                    recyclerView.setAdapter(messageAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MessageActivity.this, "Error: " +
                        databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}