package com.example.instagramclone.models;

import android.os.Parcel;
import android.os.Parcelable;

public class Users implements Parcelable {

    public static final Creator<Users> CREATOR = new Creator<Users>() {
        @Override
        public Users createFromParcel(Parcel in) {
            return new Users(in);
        }

        @Override
        public Users[] newArray(int size) {
            return new Users[size];
        }
    };

    private String description, followers, following, fullName, posts, profilePhoto,
            userName, userId;

    public Users() {
    }

    public Users(String description, String followers, String following, String fullName,
                 String posts, String profilePhoto, String userName, String userId) {
        this.description = description;
        this.followers = followers;
        this.following = following;
        this.fullName = fullName;
        this.posts = posts;
        this.profilePhoto = profilePhoto;
        this.userName = userName;
        this.userId = userId;
    }

    protected Users(Parcel in) {
        description = in.readString();
        followers = in.readString();
        following = in.readString();
        fullName = in.readString();
        posts = in.readString();
        profilePhoto = in.readString();
        userName = in.readString();
        userId = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(description);
        dest.writeString(followers);
        dest.writeString(following);
        dest.writeString(fullName);
        dest.writeString(posts);
        dest.writeString(profilePhoto);
        dest.writeString(userName);
        dest.writeString(userId);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFollowers() {
        return followers;
    }

    public void setFollowers(String followers) {
        this.followers = followers;
    }

    public String getFollowing() {
        return following;
    }

    public void setFollowing(String following) {
        this.following = following;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPosts() {
        return posts;
    }

    public void setPosts(String posts) {
        this.posts = posts;
    }

    public String getProfilePhoto() {
        return profilePhoto;
    }

    public void setProfilePhoto(String profilePhoto) {
        this.profilePhoto = profilePhoto;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "Users{" +
                "Discription='" + description + '\'' +
                ", Followers='" + followers + '\'' +
                ", Following='" + following + '\'' +
                ", FullName='" + fullName + '\'' +
                ", Posts='" + posts + '\'' +
                ", ProfilePhoto='" + profilePhoto + '\'' +
                ", Username='" + userName + '\'' +
                ", User_id='" + userId + '\'' +
                '}';
    }
}