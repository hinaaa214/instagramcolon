package com.example.instagramclone.Messages.Notification;

public class MyResponse {
    public int success;
}
