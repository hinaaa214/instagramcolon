package com.example.instagramclone.models;

public class PrivateDetails {

    private String userId, email, gender, birthDate;

    public PrivateDetails() {
    }

    public PrivateDetails(String userId, String email, String gender, String birthDate) {
        this.userId = userId;
        this.email = email;
        this.gender = gender;
        this.birthDate = birthDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    @Override
    public String toString() {
        return "privatedetails{" +
                "user_id='" + userId + '\'' +
                ", Email='" + email + '\'' +
                ", Gender='" + gender + '\'' +
                ", Birthdate='" + birthDate + '\'' +
                '}';
    }
}
