package com.example.instagramclone.Messages;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager2.widget.ViewPager2;

import com.example.instagramclone.Messages.Adapter.PageAdapter;
import com.example.instagramclone.R;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.Objects;

public class ChatActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        Toolbar toolbar = findViewById(R.id.ChatActivity_toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Instagram");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ViewPager2 viewPager = findViewById(R.id.ChatActivity_mainTabPager);
        PageAdapter pageAdapter = new PageAdapter(this);
        viewPager.setAdapter(pageAdapter);

        TabLayout tabLayout = findViewById(R.id.ChatActivity_mainTabs);

        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            if (position == 0) {
                tab.setText("Chats");
                tab.setContentDescription("Chats Tab");
            } else if (position == 1) {
                tab.setText("Friends");
                tab.setContentDescription("Friends Tab");
            }
        }).attach();
    }
}