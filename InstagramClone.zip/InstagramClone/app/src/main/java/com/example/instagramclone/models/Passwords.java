package com.example.instagramclone.models;

public class Passwords {

    private String password;

    public Passwords(String password) {
        this.password = password;
    }

    public Passwords() {
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Passwords{" +
                "Password='" + password + '\'' +
                '}';
    }
}
