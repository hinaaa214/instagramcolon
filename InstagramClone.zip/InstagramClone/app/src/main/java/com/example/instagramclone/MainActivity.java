package com.example.instagramclone;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;


public class MainActivity extends AppCompatActivity {

    ImageView insta_logo;
    TextView mazharrehan;
    TextView frm;
    FirebaseAuth fbAuth;
    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (isOnline()) {
            load();
        } else {
            try {
                new AlertDialog.Builder(MainActivity.this).setTitle("Error").setMessage("Internet not available, Cross check your internet connectivity").setCancelable(false).setIcon(android.R.drawable.ic_dialog_alert).setNeutralButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        load();
                    }
                }).show();
            } catch (Exception e) {
                Log.d("TAG", "Show Dialog: " + e.getMessage());
            }
        }
    }

    public boolean isOnline() {
        ConnectivityManager conMgr = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = conMgr.getActiveNetworkInfo();

        return netInfo != null && netInfo.isConnected() && netInfo.isAvailable();
    }

    public void load() {
        insta_logo = findViewById(R.id.insta_logo);
        mazharrehan = findViewById(R.id.mazharrehan);
        frm = findViewById(R.id.from);

        insta_logo.animate().alpha(0f).setDuration(0);
        mazharrehan.animate().alpha(0f).setDuration(0);

        insta_logo.animate().alpha(1f).setDuration(1000).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                mazharrehan.animate().alpha(1f).setDuration(800);

            }
        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                fbAuth = FirebaseAuth.getInstance();
                if (fbAuth.getCurrentUser() != null) {
                    if (fbAuth.getCurrentUser().isEmailVerified()) {
                        Intent n = new Intent(MainActivity.this, com.example.instagramclone.Home.class);
                        startActivity(n);
                        finish();
                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setMessage("Check whether you have verified your Email, Otherwise please verify");
                        builder.setCancelable(false);
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                Intent intent = new Intent(MainActivity.this, com.example.instagramclone.Login.class);
                                startActivity(intent);
                                finish();
                            }
                        });
                        AlertDialog alert = builder.create();
                        alert.show();
                        fbAuth.signOut();
                    }
                } else {
                    Intent intent = new Intent(MainActivity.this, com.example.instagramclone.Login.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, 3000);
    }
}