package com.example.instagramclone;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.instagramclone.ReusableCode.ReusableCodeForAll;
import com.example.instagramclone.models.Passwords;
import com.example.instagramclone.models.Users;
import com.example.instagramclone.models.PrivateDetails;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Objects;

public class Registration extends AppCompatActivity {

    TextView tvAlreadyHaveAccount;
    TextInputLayout tilName, tilUsername, tilEmail, tilPassword, tilGender, tilBio;
    EditText etBirthDate;
    int year, month, day;
    Button btnSignup;
    FirebaseAuth FAuth;
    DatabaseReference databaseReference;
    FirebaseDatabase firebaseDatabase;
    String name, username, email, password, gender, userBio, birth;
    String userId;
    AnimationDrawable anim;
    String emailpattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        tvAlreadyHaveAccount = findViewById(R.id.tvAlreadyHaveAccount);
        etBirthDate = findViewById(R.id.etBirthDate);
        tilName = findViewById(R.id.tilName);
        tilUsername = findViewById(R.id.tilUsername);
        tilEmail = findViewById(R.id.tilEmail);
        tilPassword = findViewById(R.id.tilPassword);
        tilGender = findViewById(R.id.tilGender);
        tilBio = findViewById(R.id.tilBio);
        btnSignup = findViewById(R.id.btnSignup);

//******************************BACKGROUND ANIMATION*************************
        RelativeLayout container = findViewById(R.id.relative_registration);
        anim = (AnimationDrawable) container.getBackground();
        anim.setEnterFadeDuration(6000);
        anim.setExitFadeDuration(2000);
//****************************************************************************

        etBirthDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(Registration.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        etBirthDate.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                    }
                }, year, month, day);
                datePickerDialog.show();

            }
        });

        tvAlreadyHaveAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Registration.this, Login.class);
                startActivity(intent);
                finish();
            }
        });


        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
        FAuth = FirebaseAuth.getInstance();
//        useridd = FAuth.getCurrentUser().getUid();


        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                name = Objects.requireNonNull(tilName.getEditText()).getText().toString().trim();
                username = Objects.requireNonNull(tilUsername.getEditText()).getText().toString().trim();
                email = Objects.requireNonNull(tilEmail.getEditText()).getText().toString().trim();
                password = Objects.requireNonNull(tilPassword.getEditText()).getText().toString().trim();
                gender = Objects.requireNonNull(Registration.this.tilGender.getEditText()).getText().toString().trim();
                userBio = Registration.this.tilBio.getEditText().getText().toString().trim();
                birth = etBirthDate.getText().toString().trim();

                if (isValid()) {
                    databaseReference.child("Users").orderByChild("Username").equalTo(username).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                Toast.makeText(Registration.this, "Username already exists. Please try other username.", Toast.LENGTH_SHORT).show();
                            } else {
                                final ProgressDialog mDialog = new ProgressDialog(Registration.this);
                                mDialog.setCancelable(false);
                                mDialog.setCanceledOnTouchOutside(false);
                                mDialog.setMessage("Registering please wait...");
                                mDialog.show();

                                FAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {

                                            userId = Objects.requireNonNull(FAuth.getCurrentUser()).getUid();

                                            addUsers(userBio, name, username);
                                            addPrivateDetails(userId, email, gender, birth);
                                            addPasswords(password);

                                            mDialog.dismiss();

                                            FAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        AlertDialog.Builder builder = new AlertDialog.Builder(Registration.this);
                                                        builder.setMessage("Registered Successfully,Please Verify your Email");
                                                        builder.setCancelable(false);
                                                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                            @Override
                                                            public void onClick(DialogInterface dialog, int which) {
                                                                tilName.getEditText().setText("");
                                                                tilUsername.getEditText().setText("");
                                                                tilEmail.getEditText().setText("");
                                                                tilPassword.getEditText().setText("");
                                                                Registration.this.tilGender.getEditText().setText("");
                                                                Registration.this.tilBio.getEditText().setText("");
                                                                etBirthDate.setText("");
                                                                startActivity(new Intent(getApplicationContext(), Login.class));
                                                                finish();
                                                            }
                                                        });
                                                        AlertDialog alert = builder.create();
                                                        alert.show();
                                                    } else {
                                                        mDialog.dismiss();
                                                        ReusableCodeForAll.ShowAlert(Registration.this, "Error", task.getException().getMessage());
                                                    }
                                                }
                                            });
                                        } else {
                                            mDialog.dismiss();
                                            ReusableCodeForAll.ShowAlert(Registration.this, "Error", task.getException().getMessage());
                                        }

                                    }
                                });

                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }


            }
        });

    }

    public boolean isValid() {
        tilEmail.setErrorEnabled(false);
        tilEmail.setError("");
        tilName.setErrorEnabled(false);
        tilName.setError("");
        tilUsername.setErrorEnabled(false);
        tilUsername.setError("");
        tilPassword.setErrorEnabled(false);
        tilPassword.setError("");
        tilGender.setErrorEnabled(false);
        tilGender.setError("");

        boolean isValidname = false, isValidemail = false, isvalidpassword = false, isvalid = false, isvalidmobileno = false, isvalidgender = false, isvalidusername = false;
        if (TextUtils.isEmpty(name)) {
            tilName.setErrorEnabled(true);
            tilName.setError("Fullname is required");
        } else {
            isValidname = true;
        }
        if (TextUtils.isEmpty(email)) {
            tilEmail.setErrorEnabled(true);
            tilEmail.setError("Email is required");
        } else {
            if (email.matches(emailpattern)) {
                isValidemail = true;
            } else {
                tilEmail.setErrorEnabled(true);
                tilEmail.setError("Enter a valid Email Address");
            }

        }
        if (TextUtils.isEmpty(password)) {
            tilPassword.setErrorEnabled(true);
            tilPassword.setError("Password is required");
        } else {
            if (password.length() < 6) {
                tilPassword.setErrorEnabled(true);
                tilPassword.setError("password is too weak");
            } else {
                isvalidpassword = true;
            }
        }
        if (TextUtils.isEmpty(gender)) {
            tilGender.setErrorEnabled(true);
            tilGender.setError("Field cannot be empty");
        } else {
            isvalidgender = true;
        }
        if (TextUtils.isEmpty(username)) {
            tilUsername.setErrorEnabled(true);
            tilUsername.setError("Field cannot be empty");
        } else {
            isvalidusername = true;
        }

        isvalid = isValidname && isValidemail && isvalidpassword && isvalidmobileno && isvalidgender && isvalidusername;
        return isvalid;
    }

    //******************************FUNCTIONS TO ADD DATA'S TO FIREBASE*************************
    public void addUsers(String Discription, String FullName, String Username) {

//        String discription, String followers, String following, String fullName, String posts, String profilePhoto, String username, String user_id
        Users user = new Users(Discription, "0", "0", FullName, "0", null, Username, userId);
        databaseReference.child("Users").child(userId).setValue(user);
    }

    public void addPrivateDetails(String user_id, String email, String gender, String birthdate) {
        PrivateDetails details = new PrivateDetails(user_id, email, gender, birthdate);
        databaseReference.child("PrivateDetails").child(userId).setValue(details);
    }

    public void addPasswords(String passwords) {

        Passwords pass = new Passwords(passwords);
        databaseReference.child("Passwords").child(userId).setValue(pass);

    }
//*******************************************************************************

    //******************************BACKGROUND ANIMATION*************************
    // Starting animation:- start the animation on onResume.
    @Override
    protected void onResume() {
        super.onResume();
        if (anim != null && !anim.isRunning()) anim.start();
    }

    // Stopping animation:- stop the animation on onPause.
    @Override
    protected void onPause() {
        super.onPause();
        if (anim != null && anim.isRunning()) anim.stop();
    }
//****************************************************************************

}