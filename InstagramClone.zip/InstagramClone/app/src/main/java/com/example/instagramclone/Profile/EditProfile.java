package com.example.instagramclone.Profile;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.instagramclone.R;
import com.example.instagramclone.models.PrivateDetails;
import com.example.instagramclone.models.Users;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class EditProfile extends AppCompatActivity {

    // Creating Hooks for the UI elements
    ImageView ivProfilePhoto, ivSubmit;
    TextView tvEmail, tvGender, tvBirth;
    TextInputEditText tietName, tietUsername, tietBio;
    DatabaseReference dbReference, dbData;
    StorageReference storageRef, profilePhotoRef; // storageRef - for uploading images, profilePhotoRef - for storing the image URL

    String name, username, bio, userId;

    int PICK_IMAGE_REQUEST = 1;
    Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        ivProfilePhoto = findViewById(R.id.civUserImg);
        tietName = findViewById(R.id.tietName);
        tietUsername = findViewById(R.id.tietUsername);
        tietBio = findViewById(R.id.tietBio);
        ivSubmit = findViewById(R.id.rightt);
        tvEmail = findViewById(R.id.tvEmail);
        tvGender = findViewById(R.id.gender);
        tvBirth = findViewById(R.id.tvBirth);

        storageRef = FirebaseStorage.getInstance().getReference();


//******************************RETRIEVING DATA***************************
        final String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        dbReference = FirebaseDatabase.getInstance().getReference("Users").child(currentUserId);
        dbReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                final Users user = snapshot.getValue(Users.class);
                tietName.setText(user.getFullName());
                tietUsername.setText(user.getUserName());
                tietBio.setText(user.getDescription());
                Glide.with(EditProfile.this)
                        .load(user.getProfilePhoto())
                        .into(ivProfilePhoto);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        FirebaseDatabase.getInstance().getReference("privateDetails")
                .child(currentUserId).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        final PrivateDetails privateDetails = snapshot.getValue(PrivateDetails.class);
                        tvEmail.setText(privateDetails.getEmail());
                        tvGender.setText(privateDetails.getGender());
                        tvBirth.setText(privateDetails.getBirthDate());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
//************************************************************************


        ivProfilePhoto.setOnClickListener(v -> openFileChooser());

        ivSubmit.setOnClickListener(v -> {
            name = tietName.getText().toString().trim();
            username = tietUsername.getText().toString().trim();
            bio = tietBio.getText().toString().trim();

            DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
            ref.child("Users").orderByChild("Username").equalTo(username).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        Toast.makeText(EditProfile.this, "Username already exists. Please try other username.", Toast.LENGTH_SHORT).show();
                    } else {
                        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
                        dbData = FirebaseDatabase.getInstance().getReference("Users").child(userId);
                        dbData.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                final ProgressDialog mDialog = new ProgressDialog(EditProfile.this);
                                mDialog.setCancelable(false);
                                mDialog.setCanceledOnTouchOutside(false);
                                mDialog.setMessage("Updating please wait...");
                                mDialog.show();
                                dbData.child("fullName").setValue(name);
                                dbData.child("username").setValue(username);
                                dbData.child("description").setValue(bio);
                                // Set profile photo
                                if (imageUri != null) {
                                    profilePhotoRef = storageRef.child("photos/users/" + "/" + userId + "/profilePhoto"); // path where the image will be stored
                                    profilePhotoRef.putFile(imageUri).addOnSuccessListener(taskSnapshot -> profilePhotoRef.getDownloadUrl().addOnSuccessListener(uri -> dbData.child("profilePhoto").setValue(uri.toString())));
                                }

                                mDialog.dismiss();
                                Toast.makeText(EditProfile.this, "Profile Updated Successfully!", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(EditProfile.this, Account_Settings.class));
                                finish();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        });
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            imageUri = data.getData();
            ivProfilePhoto.setImageURI(imageUri);
        }

        super.onActivityResult(requestCode, resultCode, data);
    }
}