plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.google.gms.google.services)
}

android {
    namespace = "com.example.instagramclone"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.instagramclone"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {

    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar"))))

    implementation(libs.activity)
    implementation(libs.support.annotations)
    implementation(libs.annotation)
    implementation(libs.support.v4)
    implementation(libs.mediarouter)
    implementation(libs.support.v13)
    implementation(libs.legacy.support.v13)


    // AndroidX and Material dependencies
    implementation(libs.appcompat)
    implementation(libs.appcompat.v7)
    implementation(libs.constraintlayout)
    implementation(libs.material)
    implementation(libs.legacy.support.v4)
    implementation(libs.cardview) // Using fixed version

    // Firebase dependencies
    implementation(libs.firebase.auth)
    implementation(libs.firebase.storage)
    implementation(libs.firebase.database)
    implementation(libs.firebase.dynamic.module.support)
    implementation(libs.firebase.analytics)
    implementation(libs.firebase.core)
    implementation(libs.firebase.messaging)


    // Testing dependencies
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)


// Image loading and processing libraries
    implementation(libs.circleimageview)
    // Glide dependency
    implementation(libs.glide)
    // Skip this if you don't want to use integration libraries or configure Glide.
    annotationProcessor(libs.compiler)
    implementation(libs.universal.image.loader)

    // Additional UI components
    implementation(libs.bottomnavigationviewex)
    implementation(libs.storiesprogressview)
    implementation(libs.library)

    // Push Notification
    implementation(libs.retrofit)
    implementation(libs.converter.gson)


    // Retrofit for networking
    implementation(libs.retrofit)
    implementation(libs.converter.gson)
}
